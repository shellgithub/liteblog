/**
 * @description 样式配置
 * @author wangfupeng
 */

export default {
    zIndex: 10000,
}
